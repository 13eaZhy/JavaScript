//module -> Car component
class Car{
  constructor(){
    this.left = 0;  // pixel from left
    this.speed = 1; //pixel per second
  }
  render(){
    //creates div and remember the reference
   this.div = document.createElement('div');
   this.div.className = 'car main';
   this.updateStyle();
    var road = document.getElementById('road');
       road.appendChild(this.div);
  }
  steerLeft(){
    this.left -= 20;
    this.updateStyle();
  }
  steerRight(){
    this.left += 20;
    this.updateStyle();
  }
  //updates div styles
  updateStyle(){
       this.div.style.left = `${this.left}px`;
  }
}
