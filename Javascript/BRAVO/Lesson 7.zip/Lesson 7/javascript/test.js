var player_car = new Car();
    player_car.render();
var road = document.getElementById('road');


function action(){
    if (event.code == "ArrowLeft"){
        player_car.steerLeft();
    }
    if (event.code == "ArrowRight"){
        player_car.steerRight();
    }
}

function animate(){
    // scoatem nr si salvam in variabila y: parseInt scoate doar nr din tot continutul
    var y = parseInt(road.style.backgroundPositionY);
    y+= player_car.speed;
    road.style.backgroundPositionY = `${y}px`;
    // console.log(road.style.backgroundPosition)
}

setInterval ( animate, 30);
