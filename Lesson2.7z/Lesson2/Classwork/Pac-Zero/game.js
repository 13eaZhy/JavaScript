//Create a simple object map
var m = new GameMap();
m.render();
