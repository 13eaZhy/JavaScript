// class of map component

//Legend : 0 = Empty ; 1 = Pacman ; 2 = Cherry;
//         3 = Bomb ; 4 = Coins;
class GameMap{
  // initializare
  constructor(){
    this.grid = [ 0,0,0,0,0,1,0,0,0,0 ];
    //                      6 ( index )
  }
  render(){
    var div = document.getElementById('map');

    var html =``;

    for (var i=0; i<10; i++){
      html += `<div></div>`;
    }
    div.innerHTML = html;
  }
}
